<!DOCTYPE html>
<html lang="en">

<head>
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <div class="fnav">
            <div class="log">

            </div>
            <ul>
                <li class="logo"><a href="#"> Toursim</a></li>
                <li><a href="about.asp">Login</a></li>
                <li><a href="about.asp">Signup</a></li>
                <li><a href="about.asp">About</a></li>
                <li><a href="about.asp">Author</a></li>
                <li><a href="news.asp">Travel News</a></li>
                <li><a href="contact.asp">Travel Episode</a></li>
                <li><a href="about.asp">Inspiration</a></li>
                <li><a href="contact.asp">Explore</a></li>
                <li><a href="contact.asp">place</a></li>
                <li><a href="contact.asp">Blog</a></li>
                <li><a href="admin.php">Admin</a></li>
                <li><a href="about.asp">Gallery</a></li>
                <li><a href="planing.php">Planning</a></li>
                

            </ul>
        </div>

        <div class="post">

        </div>

    </div>
    <div class="head">
        <div class="logo">
            <h3> Tour <span> World </span> GO</h3>
        </div>
    </div>



    <!-- <div class="snav">
        <ul class="mnav">
            <li><a href="about.asp">Login</a></li>
            <li><a href="about.asp">Signup</a></li>
            <li><a href="about.asp">About</a></li>
            <li><a href="about.asp">Author</a></li>
            <li><a href="news.asp">Travel News</a></li>
            <li><a href="contact.asp">Travel Episode</a></li>
            <li><a href="contact.asp">Explore</a></li>
            <li><a href="contact.asp">place</a></li>
            <li><a href="contact.asp">Blog</a></li>
            <li><a href="about.asp">Planning</a></li>
            <li><a href="about.asp">Gallery</a></li>
            <li><a href="about.asp">Inspiration</a></li>

        </ul>
    </div> -->

</body>

</html>