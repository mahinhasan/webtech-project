<!DOCTYPE html>
<html lang="en">

<head>

    <title>Home</title>
    <link rel="stylesheet" href="views/style.css">
</head>

<body>
    <div class="container">
        <div class="nav">
            <div class="log">
                
            </div>
            <ul>
                <li class="logo" ><a href="#"> Toursim</a></li>
                <li><a href="about.asp">Login</a></li>
                <li><a href="about.asp">Signup</a></li>
                <li><a href="about.asp">About</a></li>
                <li><a href="about.asp">Author</a></li>
                <li><a href="news.asp">Travel News</a></li>
                <li><a href="contact.asp">Travel Episode</a></li>
                <li><a href="contact.asp">Explore</a></li>
                <li><a href="contact.asp">place</a></li>
                <li><a href="contact.asp">Blog</a></li>
                <li><a href="about.asp">Planning</a></li>
                <li><a href="about.asp">Gallery</a></li>
                <li><a href="about.asp">Inspiration</a></li>
             
            </ul>
        </div>

        <div class="post">

        </div>

    </div>

</body>

</html>